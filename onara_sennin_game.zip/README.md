# オナラ仙人と雲の秘宝

HTML/CSS/JavaScriptだけで動く、縦長のレトロ風ミニゲームです。

## 遊び方

- PC: ← → 移動 / Space ジャンプ / Shift 風ダッシュ
- スマホ: 画面下のボタンで操作
- 目的: 金の壺を集めて右側の秘宝門へ到達

## 無料公開の方法

### GitHub Pages
1. GitHubで新規リポジトリを作成
2. `index.html` をアップロード
3. Settings → Pages
4. Deploy from a branch
5. main / root を選択
6. 発行されたURLで遊べます

### itch.io
1. このフォルダをZIP化
2. itch.ioでNew project
3. Kind of projectをHTMLにする
4. ZIPをアップロード
5. This file will be played in the browser にチェック
